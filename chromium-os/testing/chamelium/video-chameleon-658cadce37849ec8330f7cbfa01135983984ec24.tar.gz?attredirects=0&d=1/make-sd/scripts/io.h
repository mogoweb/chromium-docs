// Copyright 2014 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// I2C address
#define HDMI_I2C_ADDR 0x100 // bit[0] = current_scl/pull_scl_to_zero
                            // bit[1] = current_sda/pull_sda_to_zero
#define HDMI_SCL_ADDR 0x102 // bit[0] = current_scl/pull_scl_to_zero
#define HDMI_SDA_ADDR 0x103 // bit[0] = current_sda/pull_sda_to_zero

// HPD address
#define HPD_DP1 0x110
#define HPD_DP2 0x112
#define HPD_HDMI 0x114

// HPD value
#define HPD_SET_LOW 0x0
#define HPD_SET_HIGH 0x1
#define HPD_SET_Z 0x2

// Timestamp address
#define TSC_LO 0x118
#define TSC_HI 0x11a

// AUX address
#define DP1_SRC_BASE 0x180
#define DP1_SINK_BASE 0x188
#define DP2_SRC_BASE 0x190
#define DP2_SINK_BASE 0x198

// AUX Registers
#define RX_CSR 0x0
#define RX_BYTES_RECEIVED 0x2
#define RX_BUFFER 0x3
#define TX_CSR 0x4
#define TX_BYTES_SENT 0x6
#define TX_BUFFER 0x7

// RX_CSR bits
#define RX_BIT_RESET 0x1
#define RX_BIT_STARTED 0x2
#define RX_BIT_ENDED 0x4
#define RX_BIT_ERROR 0x8

// TX_CST bits
#define TX_BIT_TRIGGER 0x1
#define TX_BIT_STOP 0x2
#define TX_BIT_BUSY 0x4

static inline int get_bit(int reg, int bit) {
    unsigned char byte = *(volatile unsigned char *)reg;
    return !!(byte & bit);
}

static inline void set_bit(int reg, int bit) {
    *(volatile unsigned char *)reg = bit;
}

static inline unsigned char get_byte(int reg) {
    return *(volatile unsigned char *)reg;
}

static inline void set_byte(int reg, unsigned char byte) {
    *(volatile unsigned char *)reg = byte;
}

static inline void clear_tsc() {
    *(volatile unsigned int *)TSC_LO = 0;
}

// The time unit is 65536/50M seconds (=1.31072us).
static inline unsigned int read_tsc_lo() {
    return *(volatile unsigned int *)TSC_LO;
}

// The time unit is 1/50M seconds (20ns).
static inline unsigned int read_tsc_hi() {
    return *(volatile unsigned int *)TSC_HI;
}
