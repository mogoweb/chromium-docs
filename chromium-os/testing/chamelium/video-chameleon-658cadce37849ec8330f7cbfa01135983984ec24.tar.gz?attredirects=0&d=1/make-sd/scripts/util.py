#!/usr/bin/python
# Copyright 2014 Google Inc. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#
# Utility for memory access and I2C
#
import array
import sys
import ctypes
import time

libc = None
device_mem = -1

def mmap_mem(addr, length):
    O_RDWR = 00000002
    O_SYNC = 04000000 | 00010000
    fd = libc.open("/dev/mem", O_RDWR | O_SYNC)
    if fd == -1:
        return None
    PROT_READ = 0x1
    PROT_WRITE = 0x2
    MAP_SHARED = 0x01
    handle = libc.mmap(0, length, PROT_READ | PROT_WRITE, MAP_SHARED, fd, addr)
    libc.close(fd)
    return handle

def munmap_mem(addr, length):
    libc.munmap(addr, length)

def init():
    global libc, device_mem
    libc = ctypes.cdll.LoadLibrary('libc.so.6')
    device_mem = mmap_mem(0xff210000, 0x10000)

base_addr = [0xff21b000, 0xff21c000, 0xff218000, 0xff21c800]
REG_SLAVE_ADDR_DIR = 3 * 4
REG_SLAVE_OFFSET = 4 * 4
REG_TRIGGER = 5 * 4
REG_STATUS = 6 * 4
REG_LENGTH = 7 * 4
REG_TX_BUFFER_0 = 8 * 4
REG_TX_BUFFER_1 = 9 * 4
REG_RX_BUFFER_0 = 10 * 4
REG_RX_BUFFER_1 = 11 * 4

def i2c_write(bus, device, offset, values):
    base = base_addr[bus]
    mem_write(base + REG_SLAVE_ADDR_DIR, device * 2)
    mem_write(base + REG_SLAVE_OFFSET, offset)
    N = len(values)
    for i in range(0, N, 8):
        to_write = min(8, N - i)
        word0 = 0
        word1 = 0
        for j in range(0, 4):
            word0 <<= 8
            if j < to_write:
                word0 |= (values[i + j] & 0xff)
        for j in range(4, 8):
            word1 <<= 8
            if j < to_write:
                word1 |= (values[i + j] & 0xff)
        mem_write(base + REG_TX_BUFFER_0, word0)
        mem_write(base + REG_TX_BUFFER_1, word1)
        mem_write(base + REG_LENGTH, to_write)
        mem_write(base + REG_TRIGGER, 1)
        _wait_for_i2c(bus)

def i2c_fill(bus, device, data):
    for i in range(0, len(data), 8):
        bytes = data[i:i+8]
        i2c_write(bus, device, i, [ord(x) for x in bytes])
        # M24C02 eeprom needs at most 5ms write time.
        # FM24CL04B fram doesn't need this delay.
        time.sleep(0.005)

def i2c_read(bus, device, offset, N):
    base = base_addr[bus]
    values = []
    mem_write(base + REG_SLAVE_ADDR_DIR, device * 2 + 1)
    for i in range(0, N, 8):
        to_read = min(8, N - i)
        mem_write(base + REG_SLAVE_OFFSET, offset + i)
        mem_write(base + REG_LENGTH, to_read)
        mem_write(base + REG_TRIGGER, 1)
        _wait_for_i2c(bus)
        word0 = mem_read(base + REG_RX_BUFFER_0)
        word1 = mem_read(base + REG_RX_BUFFER_1)
        for j in range(0, 4):
            if j < to_read:
                values.append((word0 >> 24) & 0xff)
            word0 <<= 8
        for j in range(4, 8):
            if j < to_read:
                values.append((word1 >> 24) & 0xff)
            word1 <<= 8
    return values

def _wait_for_i2c(bus):
    base = base_addr[bus]
    i = 0
    while mem_read(base + REG_STATUS) & 1:
        i += 1
        if i > 3: raise Exception("i2c busy timeout")
        time.sleep(0.001) # 1ms = 100 bits
    if mem_read(base + REG_STATUS) & 2:
        raise Exception("i2c error")

def to_print(values):
    s = ''
    for v in values:
        if v >= 0x20 and v <= 0x7e:
            s += chr(v)
        else:
            s += '.'
    return s

def i2c_dump(bus, device, N):
    header = ' ' * 5
    header += '  '.join('%x' % x for x in range(0, 16))
    header += ' ' * 4
    header += ''.join('%x' % x for x in range(0, 16))
    print header

    for i in range(0, N, 16):
        line = '%02x' % i
        line += ': '
        to_read = min(16, N - i)
        values = i2c_read(bus, device, i, to_read)
        line += ' '.join('%02x' % x for x in values)
        line += ' ' * (4 + (16 - to_read) * 3)
        line += to_print(values)
        print line

def dump_data(data):
    header = ' ' * 5
    header += '  '.join('%x' % x for x in range(0, 16))
    header += ' ' * 4
    header += ''.join('%x' % x for x in range(0, 16))
    print header

    N = len(data)
    for i in range(0, N, 16):
        line = '%02x' % i
        line += ': '
        to_read = min(16, N - i)
        values = data[i:i+16]
        line += ' '.join('%02x' % x for x in values)
        line += ' ' * (4 + (16 - to_read) * 3)
        line += to_print(values)
        print line

def mem_read(addr):
    assert device_mem != -1
    assert (addr >> 16) == 0xff21
    return ctypes.c_uint.from_address(device_mem + (addr & 0xffff)).value

def mem_write(addr, data):
    assert device_mem != -1
    assert (addr >> 16) == 0xff21
    ctypes.c_uint.from_address(device_mem + (addr & 0xffff)).value = data

def mem_dump(addr, size):
    pages = (size + 4095) / 4096
    tmp_mem = mmap_mem(addr, pages * 4096)
    buf = ctypes.create_string_buffer(size)
    ctypes.memmove(buf, tmp_mem, size)
    munmap_mem(tmp_mem, pages * 4096)
    return buf

def mem_fill(addr, data):
    offset = addr & 4095
    aligned_addr = addr - offset
    size = offset + len(data)
    pages = (size + 4095) / 4096
    tmp_mem = mmap_mem(aligned_addr, pages * 4096)
    ctypes.memmove(tmp_mem + offset, data, len(data))
    munmap_mem(tmp_mem, pages * 4096)

init()
