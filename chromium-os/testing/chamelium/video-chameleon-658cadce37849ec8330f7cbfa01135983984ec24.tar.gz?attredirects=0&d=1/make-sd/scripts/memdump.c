// Copyright 2014 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

void usage_exit()
{
    fprintf(stderr, "Usage: memdump2file [-a start_address] [-b start_address2] size_in_4k_pages filename\n");
    exit(1);
}

unsigned int read_uint(char *s)
{
  errno = 0;
  char *endptr;
  unsigned int v = strtoul(s, &endptr, 0);
  if (errno || *endptr != '\0') {
    fprintf(stderr, "failed to parse argument: '%s'\n", s);
    usage_exit();
  }
  return v;
}

int main(int argc, char **argv)
{
  int opt;
  int dual = 0;
  unsigned int start_a = 0xc0000000;
  unsigned int start_b;

  while ((opt = getopt(argc, argv, "a:b:")) != -1) {
    switch (opt) {
      case 'a':
        start_a = read_uint(optarg);
        break;
      case 'b':
        start_b = read_uint(optarg);
        dual = 1;
        break;
      default:
        usage_exit();
    }
  }

  if (optind + 1 >= argc)
    usage_exit();

  unsigned long size = read_uint(argv[optind]);

  int fd = open("/dev/mem", O_RDWR | O_SYNC);
  if (fd == -1) {
    perror("can't open /dev/mem\n");
    exit(1);
  }

  int ofd = open(argv[optind+1], O_RDWR | O_CREAT, 0644);
  if (ofd == -1) {
    perror("can't open dest file\n");
    exit(1);
  }

  int page_size = getpagesize();
  unsigned int total_size = size * page_size;
  printf("start = %x, total_size = 0x%x\n", start_a, total_size);

  void *src = mmap(0, total_size, PROT_READ | PROT_WRITE,
                    MAP_SHARED, fd, start_a);
  if (src == MAP_FAILED) {
    perror("cannot mmap src\n");
    exit(1);
  }

  void *src2;
  if (dual) {
    printf("start2 = %x, total_size = 0x%x\n", start_b, total_size);
    src2 = mmap(0, total_size, PROT_READ | PROT_WRITE,
                MAP_SHARED, fd, start_b);
    if (src2 == MAP_FAILED) {
      perror("cannot mmap src2\n");
      exit(1);
    }
  }

  unsigned int out_size = dual ? total_size * 2 : total_size;
  ftruncate(ofd, out_size);
  void *dst = mmap(0, out_size, PROT_READ | PROT_WRITE, MAP_SHARED, ofd, 0);
  if (dst == MAP_FAILED) {
    perror("cannot mmap dst\n");
    exit(1);
  }

  if (dual) {
    char *p1 = malloc(total_size);
    char *p2 = malloc(total_size);
    char *q = (char *)dst;
    memcpy(p1, src, total_size);
    memcpy(p2, src2, total_size);
    unsigned int i, j;
    unsigned int n = total_size / 3 * 3;
    // copy 2 RGB pixels each loop
    for (i = 0; i < n; i += 3) {
      q[2*i] = p1[i];
      q[2*i+1] = p1[i+1];
      q[2*i+2] = p1[i+2];
      q[2*i+3] = p2[i];
      q[2*i+4] = p2[i+1];
      q[2*i+5] = p2[i+2];
    }
    free(p1);
    free(p2);
    munmap(src2, total_size);
  } else {
    memcpy(dst, src, total_size);
  }
  munmap(dst, out_size);
  munmap(src, total_size);
  close(ofd);
  close(fd);

  return 0;
}
