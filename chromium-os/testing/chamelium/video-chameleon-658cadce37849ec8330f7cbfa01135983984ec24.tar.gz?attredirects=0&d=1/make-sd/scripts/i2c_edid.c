// Copyright 2014 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//
// I2C slave that emulates an EDID EEPROM.
//

// Compile this with:
// $ msp430-gcc -mmcu=msp430x1111 -mdisable-watchdog -O2 program.c
// $ msp430-objcopy -O binary a.out a.bin

#include "io.h"
#define printf(...)

#define EDID_ADDR 0x500
#define I2C_ADDR_EDID 0x50

#define RETURN_ON_ERR(x) if (x) return 1;

#define SCL_PORT 1
#define GPIO_HIGH 1
#define GPIO_LOW 0

#define I2C_BOTH_HIGH 3
#define I2C_START SCL_PORT

#define SCL(i2c) ((i2c) & SCL_PORT)

register volatile int *i2c_ptr asm ("r11");
register volatile char *sda_ptr asm ("r10");
register volatile char *scl_ptr asm ("r9");

void i2c_init()
{
  *sda_ptr = !GPIO_HIGH;
  *scl_ptr = !GPIO_HIGH;
}

void wait_until_scl_high()
{
  while (!(*scl_ptr));
}

/**
 * Returns 1 if (unexpected) start/stop is seen.
 */
int wait_until_scl_low()
{
  int i2c = *i2c_ptr;
  int start_stop = i2c ^ 0x02;
  if (!SCL(i2c)) return 0;
  while (i2c == (*i2c_ptr)); // wait until change
  return ((*i2c_ptr) == start_stop);
}

void wait_for_start()
{
  *sda_ptr = !GPIO_HIGH; // release sda

  do {
    while ((*i2c_ptr) != I2C_BOTH_HIGH);
    while ((*i2c_ptr) == I2C_BOTH_HIGH);
  } while ((*i2c_ptr) != I2C_START || wait_until_scl_low(i2c_ptr));
}

/**
 * precondition: scl low
 * Returns 1 if (unexpected) start/stop is seen.
 */
int read_one_bit(int *bitp)
{
  *sda_ptr = !GPIO_HIGH; // release sda
  wait_until_scl_high();
  *bitp = *sda_ptr;
  return wait_until_scl_low();
}

/*
 * precondition: scl low
 * Returns 1 if (unexpected) start/stop is seen.
 */
int write_one_bit(int bit)
{
  //*scl_ptr = !GPIO_LOW; // clock stretch
  *sda_ptr = !bit;
  //*scl_ptr = !GPIO_HIGH; // clock stretch end

  wait_until_scl_high();
  return wait_until_scl_low();
}

int send_ack()
{
  return write_one_bit(GPIO_LOW);
}

int write_one_byte(int byte, int *ackp)
{
  int i;
  for (i = 0x80; i; i >>= 1) {
    RETURN_ON_ERR(write_one_bit((byte & i)));
  }
  return read_one_bit(ackp);
}

#define RW_WRITE 0
#define RW_READ 1

/**
 * expected_rw: RW_WRITE or RW_READ
 * Returns 1 if address or the rw is not expected or start/stop is seen unexpectedly
 */
int read_address(int expected_rw)
{
  int i, bit, addr = 0, rw;
  for (i = 0; i < 7; ++i) {
    RETURN_ON_ERR(read_one_bit(&bit));
    addr = (addr << 1) | bit;
  }
  RETURN_ON_ERR(read_one_bit(&rw));
  if (addr == I2C_ADDR_EDID) {
    return send_ack() | (rw != expected_rw);
  } else {
    printf("wrong addr %d\n", addr);
    return 1;
  }
}

int read_offset(int *offsetp)
{
  int i, bit, offset = 0;
  for (i = 0; i < 8; ++i) {
    RETURN_ON_ERR(read_one_bit(&bit));
    offset = (offset << 1) | bit;
  }
  *offsetp = offset;
  return send_ack();
}

int write_bytes_until_nack(unsigned char *edid)
{
  int nack = 0;
  unsigned char *p;
  // don't care if p goes out of bound
  for (p = edid; !nack; ++p) {
    RETURN_ON_ERR(write_one_byte(*p, &nack));
  }
  return 0;
}

int main()
{
  unsigned char *edid = (unsigned char *) EDID_ADDR;
  i2c_ptr = ((volatile int *) HDMI_I2C_ADDR);
  sda_ptr = ((volatile char *) HDMI_SDA_ADDR);
  scl_ptr = ((volatile char *) HDMI_SCL_ADDR);
  int offset;

  printf("slave starts.\n");

  i2c_init();

  while (1) {
    int rc = 0;
    int step = 0;
    wait_for_start();
    rc = read_address(RW_WRITE);
    if (!rc) {
      step++;
      rc = read_offset(&offset);
    }
    if (!rc) {
      step++;
      wait_for_start();
      rc = read_address(RW_READ);
    }
    if (!rc) {
      step++;
      rc = write_bytes_until_nack(edid + offset);
    }
    if (rc) {
      printf("Hmm...%d %d\n", step, offset);
    }
  }
  return 0;
}
