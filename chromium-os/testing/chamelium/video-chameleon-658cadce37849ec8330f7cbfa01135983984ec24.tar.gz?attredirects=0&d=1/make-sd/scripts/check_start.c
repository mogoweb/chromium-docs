// Copyright 2014 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//
// Pulse DP2 HPD when a message is found on DP1 AUX
//

// Compile this with:
// $ msp430-gcc -mmcu=msp430x1111 -mdisable-watchdog -O2 program.c
// $ msp430-objcopy -O binary a.out a.bin

#include "io.h"

void clear_hpd_dp2() {
    *(volatile unsigned char *)HPD_DP2 = HPD_SET_LOW;
}

void pulse_hpd_dp2() {
    *(volatile unsigned char *)HPD_DP2 = HPD_SET_HIGH;
    *(volatile unsigned char *)HPD_DP2 = HPD_SET_LOW;
}

struct {
    volatile int mark_begin;
    volatile int line_no;
    volatile int transaction_cnt;
    volatile int mark_end;
} X;

#define LLL X.line_no = __LINE__;

// Returns 0 for timeout or other errors.
void check_start(int rx_base, int rx_base2) {
    set_bit(rx_base + RX_CSR, RX_BIT_RESET);
    set_bit(rx_base2 + RX_CSR, RX_BIT_RESET);
    LLL;
    while (!get_bit(rx_base + RX_CSR, RX_BIT_STARTED))
        ;
    pulse_hpd_dp2();

    LLL;
    while (!get_bit(rx_base + RX_CSR, RX_BIT_ENDED))
        ;
    pulse_hpd_dp2();
}

int main() {
    X.mark_begin = 0xBBBB;
    X.mark_end = 0xEEEE;
    clear_hpd_dp2();
    while (1) {
        check_start(0x180, 0x188);
        X.transaction_cnt++;
    }
    return 0;
}
