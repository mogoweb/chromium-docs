// Copyright 2014 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//
// AUX forwarder between DP SRC and DP SINK
//

// Compile this with:
// $ msp430-gcc -mmcu=msp430x1111 -mdisable-watchdog -O2 program.c
// $ msp430-objcopy -O binary a.out a.bin

#include "io.h"

// The time unit is 1/50M (0.02us) seconds.
#define REPLY_TIMEOUT 20000 // 400us
#define NO_TIMEOUT 0
#define PORT_ADDR 0x500

#define BUF_SIZE 20
unsigned char buf[20];

// Returns 0 for timeout or other errors.
int copy_message(int rx_base, int tx_base, int timeout) {
    int rx_buf_ptr = 1;
    int tx_buf_ptr = 1;

    // wait for rx to start receiving a message
    set_bit(rx_base + RX_CSR, RX_BIT_RESET);
    clear_tsc();
    while (!get_bit(rx_base + RX_CSR, RX_BIT_STARTED)) {
        if (timeout != NO_TIMEOUT && read_tsc_lo() > timeout) {
            return 0;
        }
    }

    // wait for the first byte from rx
    while (1) {
        int rx_ended = get_bit(rx_base + RX_CSR, RX_BIT_ENDED);
        if (get_byte(rx_base + RX_BYTES_RECEIVED) != 0) {
            buf[0] = get_byte(rx_base + RX_BUFFER);
            break;
        }
        if (rx_ended) {
            return 0;
        }
    }

    // start tx
    set_byte(tx_base + TX_BUFFER, buf[0]);
    set_bit(tx_base + TX_CSR, TX_BIT_TRIGGER);

    // watch both rx and tx
    while (1) {
        if (get_byte(rx_base + RX_BYTES_RECEIVED) > rx_buf_ptr) {
            buf[rx_buf_ptr++] = get_byte(rx_base + RX_BUFFER);
        }
        if (get_byte(tx_base + TX_BYTES_SENT) >= tx_buf_ptr) {
            // rx should be ahead of tx, if not, either rx is finished,
            // or there is some error.
            if (tx_buf_ptr >= rx_buf_ptr) break;
            set_byte(tx_base + TX_BUFFER, buf[tx_buf_ptr++]);
        }
    }

    // finalize the tx
    set_bit(tx_base + TX_CSR, TX_BIT_STOP);
    while (get_bit(tx_base + TX_CSR, TX_BIT_BUSY))
        ;

    // if there is some error, rx may still not be finished
    while (!get_bit(rx_base + RX_CSR, RX_BIT_ENDED))
        ;

    return 1;
}

int skip_message(int rx_base, int timeout) {
    // wait for rx to start receiving a message
    set_bit(rx_base + RX_CSR, RX_BIT_RESET);
    clear_tsc();
    while (!get_bit(rx_base + RX_CSR, RX_BIT_STARTED)) {
        if (timeout != NO_TIMEOUT && read_tsc_lo() > timeout) {
            return 0;
        }
    }

    // wait for rx to stop
    while (!get_bit(rx_base + RX_CSR, RX_BIT_ENDED))
        ;

    return 1;
}

int main() {
    int port = *(unsigned int *)PORT_ADDR;
    int src_base = (port == 2) ? DP2_SRC_BASE : DP1_SRC_BASE;
    int sink_base = (port == 2) ? DP2_SINK_BASE : DP1_SINK_BASE;
    while (1) {
        if (!skip_message(src_base, NO_TIMEOUT)) {
            continue;
        }
        if (!copy_message(src_base, sink_base, NO_TIMEOUT)) {
            continue;
        }
        if (!copy_message(sink_base, src_base, REPLY_TIMEOUT)) {
            continue;
        }
    }
    return 0;
}
