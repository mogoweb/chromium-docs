#!/bin/sh
# Copyright 2014 Google Inc. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

function list_usb_disks() {
  local sd
  for sd in /sys/block/sd*; do
    if readlink -f ${sd}/device | grep -q usb &&
      [ "$(cat ${sd}/removable)" = 1 ]; then
      echo ${sd##*/}
    fi
  done
}

function main() {
  local target
  for disk in $(list_usb_disks); do
    target=/dev/$disk
    break
  done

  if [ -z $target ]; then
    echo "sd card not found"
  else
    write_image $target $*
  fi
}

function write_image() {
  local SD=$1
  echo 'Warning: will overwrite' $SD
  echo 'Enter to continue, Ctrl-C to abort.'
  read
  echo 'Write to SD card, using' $SD

  if [ "$2" != "-f" ]
  then
    echo 'Zero first 902M of SD card'
    dd if=/dev/zero of=${SD} bs=64k count=14432 oflag=direct
    sync
  fi

  echo 'Writing MBR'
  dd if=mbr of=${SD} bs=512 count=1
  sync; sleep 1

  echo 'Re-read partition table'
  partprobe ${SD}

  echo 'Write boot partition (3)'
  dd if=boot-partition.img of=${SD}3 bs=64k oflag=direct

  echo 'Write rootfs (2)'
  dd if=altera-image-socfpga_cyclone5.ext3 of=${SD}2 bs=64k oflag=direct

  echo 'Create VFAT fs (1)'
  mkfs.vfat ${SD}1
  sync; sleep 1

  local MNTDIR=$(mktemp -d)
  echo 'Copy kernel, dtb, u-boot script, fpga bitstream (1)'
  mount ${SD}1 ${MNTDIR}
  cp zImage socfpga.dtb u-boot.scr fpga.rbf ${MNTDIR}
  sync; sleep 1
  umount ${MNTDIR}; sync

  echo 'Copy scripts'
  mount ${SD}2 ${MNTDIR}
  cp -r scripts/* ${MNTDIR}/home/root
  ln -s /home/root/memdump2file ${MNTDIR}/usr/local/sbin/
  sync; sleep 1
  umount ${MNTDIR}; sync
}

set -e
main $*
# Save the generated image to a file:
# sudo dd if=/dev/sdd of=tio.image bs=64k count=14432
